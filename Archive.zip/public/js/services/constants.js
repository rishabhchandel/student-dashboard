/**
 * These constants are temporary and needs to be stored in database instead
 */
angular.module('app.constants', ['ngResource']);