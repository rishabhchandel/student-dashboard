/**
 * App filters module.
 */
angular.module('app.filters', []);