/**
 * App services module.
 */
angular.module('app.services', []);