/**
 * App directives module.
 */
angular.module('app.directives', []);