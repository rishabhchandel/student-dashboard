node version 8.6.0
mongod version 3.4.9


run following command
npm i (in dashboard folder)

cd public
npm i
bower i

cd ..

node app.js

server running on 8000

open application  in browser localhost:8000
